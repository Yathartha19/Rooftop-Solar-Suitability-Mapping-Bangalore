# Solar Panel Detection India > 2024-04-29 11:23pm
https://universe.roboflow.com/jai-inq4m/solar-panel-detection-india

Provided by a Roboflow user
License: MIT

