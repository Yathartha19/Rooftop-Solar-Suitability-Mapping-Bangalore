# bangalore > 2024-12-06 3:04pm
https://universe.roboflow.com/deduce-technologies-xmvzg/bangalore

Provided by a Roboflow user
License: CC BY 4.0

